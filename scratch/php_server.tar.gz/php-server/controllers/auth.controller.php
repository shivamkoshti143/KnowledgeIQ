<?php
// php-server/controllers/auth.controller.php

require_once __DIR__ . '/../utils/db.php';
require_once __DIR__ . '/../utils/response.php';
require_once __DIR__ . '/../utils/email.php';
require_once __DIR__ . '/../config/jwt.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../services/role.service.php';

class AuthController {
    private const STATIC_OTP = "123456";

    private static function getSecret(): string {
        return getenv('JWT_SECRET') ?: ($_ENV['JWT_SECRET'] ?? 'dev-taskiq-secret');
    }

    private static function isValidEmail(string $email): bool {
        $email = strtolower(trim($email));
        return str_ends_with($email, '@abmindia.com') || str_ends_with($email, '@abm.com');
    }

    public static function signup(): void {
        $input = get_json_input();
        $name = trim($input['name'] ?? '');
        $email = strtolower(trim($input['email'] ?? ''));
        $departmentId = !empty($input['departmentId']) ? (int)$input['departmentId'] : null;

        if (!self::isValidEmail($email)) {
            error_response("Use your ABM company email (@abmindia.com or @abm.com).", 400);
        }

        $existing = DB::getUserByEmail($email);
        if ($existing) {
            error_response("Email already registered.", 409);
        }

        $otp = self::STATIC_OTP;
        DB::createOtp($email, $otp, 'signup', ['name' => $name, 'departmentId' => $departmentId], 10);
        Mailer::sendOtpEmail($email, $otp, 'signup');

        json_response(['otpSent' => true, 'message' => "OTP sent to your email."]);
    }

    public static function login(): void {
        $input = get_json_input();
        $email = strtolower(trim($input['email'] ?? ''));

        if (!self::isValidEmail($email)) {
            error_response("Enter a valid ABM company email (@abmindia.com or @abm.com).", 400);
        }

        $user = DB::getUserByEmail($email);
        if (!$user) {
            error_response("No account found with this email.", 404);
        }

        if (($user['status'] ?? '') === 'inactive') {
            error_response("your account is inactive", 403);
        }

        $otp = self::STATIC_OTP;
        DB::createOtp($email, $otp, 'login', null, 10);
        Mailer::sendOtpEmail($email, $otp, 'login');

        json_response(['otpSent' => true, 'message' => "OTP sent to your email."]);
    }

    public static function verifyOtp(): void {
        $input = get_json_input();
        $email = strtolower(trim($input['email'] ?? ''));
        $otp = trim($input['otp'] ?? '');
        $mode = trim($input['mode'] ?? '');

        if (empty($email) || empty($otp) || empty($mode)) {
            error_response("Email, OTP, and mode are required.", 400);
        }

        $record = DB::getValidOtp($email, $otp, $mode);
        if (!$record) {
            error_response("Invalid or expired OTP.", 400);
        }

        DB::deleteOtp((int)$record['id']);

        if ($mode === 'signup') {
            $metadata = !empty($record['metadata']) ? json_decode($record['metadata'], true) : [];
            $name = $metadata['name'] ?? 'User';
            $departmentId = !empty($metadata['departmentId']) ? (int)$metadata['departmentId'] : null;

            $userId = DB::createUser($name, $email, null, 'employee', $departmentId, 'Employee');
            
            // Auto-assign default User role if configured
            $roles = RoleService::getRoles();
            foreach ($roles as $r) {
                if (strtolower($r['name']) === 'user' || strtolower($r['role_name']) === 'user') {
                    DB::updateUser($userId, ['role_id' => $r['id']]);
                    break;
                }
            }

            $user = DB::getUserById($userId);
            $permissions = RoleService::getUserPermissions($userId);
            $tokenPayload = array_merge($user, ['permissions' => $permissions]);
            $token = JWT::sign($tokenPayload, self::getSecret(), 28800);

            json_response(['token' => $token, 'user' => $tokenPayload]);
        }

        if ($mode === 'login') {
            $user = DB::getUserByEmail($email);
            if (!$user) {
                error_response("User not found.", 404);
            }

            if (($user['status'] ?? '') === 'inactive') {
                error_response("your account is inactive", 403);
            }

            $sanitized = DB::sanitizeUser($user);
            $permissions = RoleService::getUserPermissions((int)$user['id']);
            $tokenPayload = array_merge($sanitized, ['permissions' => $permissions]);
            $token = JWT::sign($tokenPayload, self::getSecret(), 28800);

            json_response(['token' => $token, 'user' => $tokenPayload]);
        }

        error_response("Invalid verification mode.", 400);
    }

    public static function me(): void {
        $authUser = AuthMiddleware::requireAuth();
        $user = DB::getUserById((int)$authUser['id']);
        if (!$user) {
            error_response("User not found", 404);
        }

        $permissions = RoleService::getUserPermissions((int)$user['id']);
        $user['permissions'] = $permissions;
        json_response($user);
    }
}
