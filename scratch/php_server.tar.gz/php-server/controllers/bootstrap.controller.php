<?php
// php-server/controllers/bootstrap.controller.php

require_once __DIR__ . '/../utils/db.php';
require_once __DIR__ . '/../utils/response.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../services/role.service.php';

class BootstrapController {
    public static function index(): void {
        $authUser = AuthMiddleware::requireAuth();
        $userId = (int)$authUser['id'];

        $departments = DB::getDepartments();
        $tags = DB::getTags();
        $categories = DB::getCategories();
        $videos = DB::getVideos();
        $comments = DB::query("SELECT * FROM comments ORDER BY createdAt ASC");
        $users = DB::getUsers();
        $notifications = DB::getNotifications($userId);
        $tasks = DB::getTasks();
        $knowledgePosts = DB::getKnowledgePosts();
        $siteSettings = DB::getSiteSettings();
        $bookmarks = DB::getUserBookmarks($userId);
        $aiChats = DB::getAiChatsByUser($userId);

        $myVideos = array_values(array_filter($videos, fn($v) => (int)$v['uploaderId'] === $userId));
        $myTasks = array_values(array_filter($tasks, fn($t) => (int)$t['uploaderId'] === $userId));
        $myKnowledgePosts = array_values(array_filter($knowledgePosts, fn($k) => (int)($k['authorId'] ?? $k['uploaderId'] ?? 0) === $userId));

        $freshUser = DB::getUserById($userId) ?: $authUser;
        $permissions = RoleService::getUserPermissions($userId);
        $freshUser['permissions'] = $permissions;

        json_response([
            'currentUser' => $freshUser,
            'departments' => $departments,
            'tags' => $tags,
            'categories' => $categories,
            'videos' => $videos,
            'comments' => $comments,
            'users' => $users,
            'notifications' => $notifications,
            'tasks' => $tasks,
            'myTasks' => $myTasks,
            'knowledgePosts' => $knowledgePosts,
            'myKnowledgePosts' => $myKnowledgePosts,
            'myVideos' => $myVideos,
            'siteSettings' => $siteSettings,
            'bookmarks' => $bookmarks,
            'aiChats' => $aiChats
        ]);
    }
}
