<?php
// php-server/controllers/recommended.controller.php

require_once __DIR__ . '/../utils/db.php';
require_once __DIR__ . '/../utils/response.php';
require_once __DIR__ . '/../middleware/auth.php';

class RecommendedController {
    public static function list(): void {
        AuthMiddleware::requireAuth();
        $recommended = DB::getRecommendedContent();
        json_response($recommended);
    }
}
