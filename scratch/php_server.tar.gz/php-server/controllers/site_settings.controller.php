<?php
// php-server/controllers/site_settings.controller.php

require_once __DIR__ . '/../utils/db.php';
require_once __DIR__ . '/../utils/response.php';
require_once __DIR__ . '/../utils/upload.php';
require_once __DIR__ . '/../middleware/auth.php';

class SiteSettingsController {
    public static function get(): void {
        $settings = DB::getSiteSettings();
        json_response($settings);
    }

    public static function update(): void {
        AuthMiddleware::requirePermission("site_settings");
        $portalName = $_POST['portalName'] ?? null;
        $logoUrl = $_POST['logoUrl'] ?? null;
        $faviconUrl = $_POST['faviconUrl'] ?? null;

        $logoFile = UploadHandler::handleSingle('logo', 'site');
        if ($logoFile) {
            $logoUrl = $logoFile['url'];
        }

        $faviconFile = UploadHandler::handleSingle('favicon', 'site');
        if ($faviconFile) {
            $faviconUrl = $faviconFile['url'];
        }

        $updates = [];
        if ($portalName !== null) $updates['portalName'] = $portalName;
        if ($logoUrl !== null) $updates['logoUrl'] = $logoUrl;
        if ($faviconUrl !== null) $updates['faviconUrl'] = $faviconUrl;

        $settings = DB::updateSiteSettings($updates);
        json_response($settings);
    }
}
