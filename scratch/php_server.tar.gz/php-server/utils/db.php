<?php
// php-server/utils/db.php

require_once __DIR__ . '/../config/database.php';

class DB {
    public static function pdo(): PDO {
        return Database::getConnection();
    }

    public static function query(string $sql, array $params = []): array {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function getOne(string $sql, array $params = []): ?array {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function execute(string $sql, array $params = []): int {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return (int)self::pdo()->lastInsertId() ?: $stmt->rowCount();
    }

    public static function toMySQLDate(?string $dateStr = null): string {
        if ($dateStr) {
            $t = strtotime($dateStr);
            return $t ? date('Y-m-d H:i:s', $t) : date('Y-m-d H:i:s');
        }
        return date('Y-m-d H:i:s');
    }

    public static function sanitizeUser(?array $user): ?array {
        if (!$user) return null;
        unset($user['password'], $user['passwordHash']);
        return $user;
    }

    // --- DEPARTMENTS ---
    public static function getDepartments(): array {
        return self::query("SELECT * FROM departments ORDER BY name ASC");
    }

    public static function getDepartmentById(int $id): ?array {
        return self::getOne("SELECT * FROM departments WHERE id = ?", [$id]);
    }

    public static function createDepartment(string $name, string $description = ''): int {
        return self::execute(
            "INSERT INTO departments (name, description, createdAt) VALUES (?, ?, ?)",
            [$name, $description, self::toMySQLDate()]
        );
    }

    public static function updateDepartment(int $id, array $data): bool {
        $fields = [];
        $params = [];
        foreach ($data as $key => $val) {
            $fields[] = "`$key` = ?";
            $params[] = $val;
        }
        if (empty($fields)) return false;
        $params[] = $id;
        self::execute("UPDATE departments SET " . implode(', ', $fields) . " WHERE id = ?", $params);
        return true;
    }

    public static function deleteDepartment(int $id): bool {
        self::execute("DELETE FROM departments WHERE id = ?", [$id]);
        return true;
    }

    // --- CATEGORIES ---
    public static function getCategories(): array {
        return self::query("SELECT * FROM categories ORDER BY name ASC");
    }

    public static function getCategoryById(int $id): ?array {
        return self::getOne("SELECT * FROM categories WHERE id = ?", [$id]);
    }

    public static function createCategory(string $name, string $description = '', ?int $departmentId = null): int {
        return self::execute("INSERT IGNORE INTO categories (name, createdAt) VALUES (?, NOW())", [$name]);
    }

    public static function updateCategory(int $id, array $data): bool {
        $name = $data['name'] ?? null;
        if (!$name) return false;
        self::execute("UPDATE categories SET name = ? WHERE id = ?", [$name, $id]);
        return true;
    }

    public static function deleteCategory(int $id): bool {
        self::execute("DELETE FROM categories WHERE id = ?", [$id]);
        return true;
    }

    // --- TAGS ---
    public static function getTags(): array {
        return self::query("SELECT * FROM tags ORDER BY name ASC");
    }

    public static function createTag(string $name): int {
        return self::execute("INSERT IGNORE INTO tags (name, createdAt) VALUES (?, ?)", [$name, self::toMySQLDate()]);
    }

    public static function deleteTag(int $id): bool {
        self::execute("DELETE FROM tags WHERE id = ?", [$id]);
        return true;
    }

    // --- USERS ---
    public static function getUsers(): array {
        $rows = self::query("
            SELECT u.*, d.name AS departmentName, 
                   COALESCE(NULLIF(r.role_name, ''), r.name) AS custom_role_name,
                   COALESCE(u.last_active_at, (SELECT MAX(al.createdAt) FROM activity_logs al WHERE al.userId = u.id), u.createdAt) AS lastActive
            FROM users u
            LEFT JOIN departments d ON u.departmentId = d.id
            LEFT JOIN roles r ON u.role_id = r.id
            ORDER BY u.name ASC
        ");
        return array_map([self::class, 'sanitizeUser'], $rows);
    }

    public static function getUserById(int $id): ?array {
        $user = self::getOne("
            SELECT u.*, d.name AS departmentName,
                   COALESCE(NULLIF(r.role_name, ''), r.name) AS custom_role_name,
                   COALESCE(u.last_active_at, (SELECT MAX(al.createdAt) FROM activity_logs al WHERE al.userId = u.id), u.createdAt) AS lastActive
            FROM users u
            LEFT JOIN departments d ON u.departmentId = d.id
            LEFT JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ", [$id]);
        return self::sanitizeUser($user);
    }

    public static function getUserByEmail(string $email): ?array {
        $user = self::getOne("
            SELECT u.*, d.name AS departmentName,
                   COALESCE(NULLIF(r.role_name, ''), r.name) AS custom_role_name,
                   COALESCE(u.last_active_at, (SELECT MAX(al.createdAt) FROM activity_logs al WHERE al.userId = u.id), u.createdAt) AS lastActive
            FROM users u
            LEFT JOIN departments d ON u.departmentId = d.id
            LEFT JOIN roles r ON u.role_id = r.id
            WHERE LOWER(u.email) = LOWER(?)
        ", [$email]);
        return $user;
    }

    public static function createUser(string $name, string $email, ?string $hashedPassword, string $role = 'employee', ?int $departmentId = null, string $title = 'Employee'): int {
        return self::execute(
            "INSERT INTO users (name, email, passwordHash, role, departmentId, title, status, createdAt) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())",
            [$name, $email, $hashedPassword, $role, $departmentId, $title]
        );
    }

    public static function updateUser(int $id, array $data): ?array {
        $allowed = ['name', 'departmentId', 'title', 'status', 'role', 'role_id', 'last_active_at', 'passwordHash'];
        $fields = [];
        $params = [];
        foreach ($data as $key => $val) {
            $col = ($key === 'password') ? 'passwordHash' : $key;
            if (in_array($col, $allowed, true)) {
                $fields[] = "`$col` = ?";
                $params[] = $val;
            }
        }
        if (!empty($fields)) {
            $params[] = $id;
            self::execute("UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?", $params);
        }
        return self::getUserById($id);
    }

    // --- TASKS ---
    public static function getTasks(array $filters = []): array {
        $sql = "
            SELECT t.*, u.name AS uploaderName, d.name AS departmentName, c.name AS categoryName,
                   (SELECT COUNT(*) FROM task_files tf WHERE tf.taskId = t.id) AS fileCount
            FROM tasks t
            LEFT JOIN users u ON t.uploaderId = u.id
            LEFT JOIN departments d ON t.departmentId = d.id
            LEFT JOIN categories c ON t.categoryId = c.id
            WHERE 1=1
        ";
        $params = [];

        if (!empty($filters['status'])) {
            $sql .= " AND t.status = ?";
            $params[] = $filters['status'];
        }
        if (!empty($filters['departmentId'])) {
            $sql .= " AND t.departmentId = ?";
            $params[] = (int)$filters['departmentId'];
        }
        if (!empty($filters['uploaderId'])) {
            $sql .= " AND t.uploaderId = ?";
            $params[] = (int)$filters['uploaderId'];
        }
        if (!empty($filters['q'])) {
            $sql .= " AND (t.title LIKE ? OR t.description LIKE ? OR t.tags LIKE ?)";
            $term = '%' . $filters['q'] . '%';
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $sql .= " ORDER BY t.createdAt DESC";
        $tasks = self::query($sql, $params);

        foreach ($tasks as &$task) {
            $task['files'] = self::getTaskFiles((int)$task['id']);
            $task['department'] = !empty($task['departmentName']) ? ['id' => $task['departmentId'], 'name' => $task['departmentName']] : null;
            $task['category'] = !empty($task['categoryName']) ? ['id' => $task['categoryId'], 'name' => $task['categoryName']] : null;
            $task['uploader'] = !empty($task['uploaderName']) ? ['id' => $task['uploaderId'], 'name' => $task['uploaderName']] : null;
        }

        return $tasks;
    }

    public static function getTaskById(int $id): ?array {
        $task = self::getOne("
            SELECT t.*, u.name AS uploaderName, d.name AS departmentName, c.name AS categoryName,
                   app.name AS approvedByName
            FROM tasks t
            LEFT JOIN users u ON t.uploaderId = u.id
            LEFT JOIN departments d ON t.departmentId = d.id
            LEFT JOIN categories c ON t.categoryId = c.id
            LEFT JOIN users app ON t.approvedBy = app.id
            WHERE t.id = ?
        ", [$id]);

        if ($task) {
            $task['files'] = self::getTaskFiles($id);
            $task['department'] = !empty($task['departmentName']) ? ['id' => $task['departmentId'], 'name' => $task['departmentName']] : null;
            $task['category'] = !empty($task['categoryName']) ? ['id' => $task['categoryId'], 'name' => $task['categoryName']] : null;
            $task['uploader'] = !empty($task['uploaderName']) ? ['id' => $task['uploaderId'], 'name' => $task['uploaderName']] : null;
        }
        return $task;
    }

    public static function createTask(array $data): int {
        return self::execute("
            INSERT INTO tasks (title, description, departmentId, categoryId, uploaderId, status, tags, createdAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ", [
            $data['title'] ?? '',
            $data['description'] ?? '',
            !empty($data['departmentId']) ? (int)$data['departmentId'] : null,
            !empty($data['categoryId']) ? (int)$data['categoryId'] : null,
            (int)$data['uploaderId'],
            $data['status'] ?? 'pending',
            $data['tags'] ?? '',
            self::toMySQLDate()
        ]);
    }

    public static function updateTask(int $id, array $data): bool {
        $allowed = ['title', 'description', 'departmentId', 'categoryId', 'status', 'tags', 'rejectionRemarks', 'approvedBy', 'approvedAt', 'isRecommended'];
        $fields = [];
        $params = [];
        foreach ($data as $key => $val) {
            if (in_array($key, $allowed, true)) {
                $fields[] = "`$key` = ?";
                $params[] = $val;
            }
        }
        if (empty($fields)) return false;
        $params[] = $id;
        self::execute("UPDATE tasks SET " . implode(', ', $fields) . " WHERE id = ?", $params);
        return true;
    }

    public static function deleteTask(int $id): bool {
        self::execute("DELETE FROM comments WHERE taskId = ? AND parentId IS NOT NULL", [$id]);
        self::execute("DELETE FROM comments WHERE taskId = ?", [$id]);
        self::execute("DELETE FROM bookmarks WHERE contentType = 'task' AND contentId = ?", [$id]);
        self::execute("DELETE FROM notifications WHERE taskId = ?", [$id]);
        self::execute("DELETE FROM task_files WHERE taskId = ?", [$id]);
        self::execute("DELETE FROM tasks WHERE id = ?", [$id]);
        return true;
    }

    public static function createTaskFile(array $data): int {
        return self::execute("
            INSERT INTO task_files (taskId, fileUrl, fileName, fileExtension, review_status, createdAt)
            VALUES (?, ?, ?, ?, ?, ?)
        ", [
            (int)$data['taskId'],
            $data['fileUrl'],
            $data['fileName'] ?? '',
            $data['fileExtension'] ?? '',
            $data['review_status'] ?? 'pending',
            self::toMySQLDate()
        ]);
    }

    public static function updateTaskFile(int $id, array $data): bool {
        $fields = [];
        $params = [];
        foreach ($data as $key => $val) {
            $fields[] = "`$key` = ?";
            $params[] = $val;
        }
        if (empty($fields)) return false;
        $params[] = $id;
        self::execute("UPDATE task_files SET " . implode(', ', $fields) . " WHERE id = ?", $params);
        return true;
    }

    public static function getTaskFiles(int $taskId): array {
        return self::query("SELECT * FROM task_files WHERE taskId = ? ORDER BY id ASC", [$taskId]);
    }

    // --- KNOWLEDGE POSTS ---
    public static function getKnowledgePosts(array $filters = []): array {
        $sql = "
            SELECT k.*, u.name AS uploaderName, d.name AS departmentName, c.name AS categoryName
            FROM knowledge_posts k
            LEFT JOIN users u ON k.uploaderId = u.id
            LEFT JOIN departments d ON k.departmentId = d.id
            LEFT JOIN categories c ON k.categoryId = c.id
            WHERE 1=1
        ";
        $params = [];

        if (!empty($filters['departmentId'])) {
            $sql .= " AND k.departmentId = ?";
            $params[] = (int)$filters['departmentId'];
        }
        if (!empty($filters['categoryId'])) {
            $sql .= " AND k.categoryId = ?";
            $params[] = (int)$filters['categoryId'];
        }
        if (!empty($filters['status'])) {
            $sql .= " AND k.status = ?";
            $params[] = $filters['status'];
        }
        if (isset($filters['isRecommended'])) {
            $sql .= " AND k.isRecommended = ?";
            $params[] = (int)$filters['isRecommended'];
        }
        if (!empty($filters['q'])) {
            $sql .= " AND (k.title LIKE ? OR k.description LIKE ? OR k.tags LIKE ?)";
            $term = '%' . $filters['q'] . '%';
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $sql .= " ORDER BY k.isRecommended DESC, k.createdAt DESC";
        $posts = self::query($sql, $params);

        foreach ($posts as &$p) {
            $p['files'] = self::getKnowledgePostFiles((int)$p['id']);
            $p['department'] = !empty($p['departmentName']) ? ['id' => $p['departmentId'], 'name' => $p['departmentName']] : null;
            $p['category'] = !empty($p['categoryName']) ? ['id' => $p['categoryId'], 'name' => $p['categoryName']] : null;
            $p['uploader'] = !empty($p['uploaderName']) ? ['id' => $p['uploaderId'], 'name' => $p['uploaderName']] : null;
        }

        return $posts;
    }

    public static function getKnowledgePostById(int $id): ?array {
        $post = self::getOne("
            SELECT k.*, u.name AS uploaderName, d.name AS departmentName, c.name AS categoryName
            FROM knowledge_posts k
            LEFT JOIN users u ON k.uploaderId = u.id
            LEFT JOIN departments d ON k.departmentId = d.id
            LEFT JOIN categories c ON k.categoryId = c.id
            WHERE k.id = ?
        ", [$id]);

        if ($post) {
            $post['files'] = self::getKnowledgePostFiles($id);
            $post['department'] = !empty($post['departmentName']) ? ['id' => $post['departmentId'], 'name' => $post['departmentName']] : null;
            $post['category'] = !empty($post['categoryName']) ? ['id' => $post['categoryId'], 'name' => $post['categoryName']] : null;
            $post['uploader'] = !empty($post['uploaderName']) ? ['id' => $post['uploaderId'], 'name' => $post['uploaderName']] : null;
        }
        return $post;
    }

    public static function createKnowledgePost(array $data): int {
        return self::execute("
            INSERT INTO knowledge_posts (title, description, uploaderId, departmentId, categoryId, tags, status, isRecommended, createdAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ", [
            $data['title'] ?? '',
            $data['description'] ?? '',
            (int)($data['uploaderId'] ?? $data['authorId'] ?? 0),
            !empty($data['departmentId']) ? (int)$data['departmentId'] : null,
            !empty($data['categoryId']) ? (int)$data['categoryId'] : null,
            $data['tags'] ?? '',
            $data['status'] ?? 'published',
            !empty($data['isRecommended']) ? 1 : 0,
            self::toMySQLDate()
        ]);
    }

    public static function updateKnowledgePost(int $id, array $data): bool {
        $allowed = ['title', 'description', 'departmentId', 'categoryId', 'tags', 'status', 'isRecommended'];
        $fields = [];
        $params = [];
        foreach ($data as $key => $val) {
            if (in_array($key, $allowed, true)) {
                $fields[] = "`$key` = ?";
                $params[] = $val;
            }
        }
        if (empty($fields)) return false;
        $params[] = $id;
        self::execute("UPDATE knowledge_posts SET " . implode(', ', $fields) . " WHERE id = ?", $params);
        return true;
    }

    public static function deleteKnowledgePost(int $id): bool {
        self::execute("DELETE FROM bookmarks WHERE contentType = 'knowledge' AND contentId = ?", [$id]);
        self::execute("DELETE FROM knowledge_post_files WHERE knowledgePostId = ?", [$id]);
        self::execute("DELETE FROM knowledge_posts WHERE id = ?", [$id]);
        return true;
    }

    public static function createKnowledgePostFile(array $data): int {
        return self::execute("
            INSERT INTO knowledge_post_files (knowledgePostId, fileUrl, fileName, fileExtension, createdAt)
            VALUES (?, ?, ?, ?, ?)
        ", [
            (int)$data['knowledgePostId'],
            $data['fileUrl'],
            $data['fileName'] ?? '',
            $data['fileExtension'] ?? '',
            self::toMySQLDate()
        ]);
    }

    public static function getKnowledgePostFiles(int $postId): array {
        return self::query("SELECT * FROM knowledge_post_files WHERE knowledgePostId = ? ORDER BY id ASC", [$postId]);
    }

    // --- VIDEOS ---
    public static function getVideos(array $filters = []): array {
        $sql = "
            SELECT v.*, u.name AS uploaderName, d.name AS departmentName, c.name AS categoryName
            FROM videos v
            LEFT JOIN users u ON v.uploaderId = u.id
            LEFT JOIN departments d ON v.departmentId = d.id
            LEFT JOIN categories c ON v.categoryId = c.id
            WHERE 1=1
        ";
        $params = [];

        if (!empty($filters['status'])) {
            $sql .= " AND v.status = ?";
            $params[] = $filters['status'];
        }
        if (!empty($filters['departmentId'])) {
            $sql .= " AND v.departmentId = ?";
            $params[] = (int)$filters['departmentId'];
        }
        if (!empty($filters['uploaderId'])) {
            $sql .= " AND v.uploaderId = ?";
            $params[] = (int)$filters['uploaderId'];
        }
        if (!empty($filters['q'])) {
            $sql .= " AND (v.title LIKE ? OR v.description LIKE ? OR v.tags LIKE ?)";
            $term = '%' . $filters['q'] . '%';
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $sql .= " ORDER BY v.createdAt DESC";
        $videos = self::query($sql, $params);
        foreach ($videos as &$v) {
            $v['department'] = !empty($v['departmentName']) ? ['id' => $v['departmentId'], 'name' => $v['departmentName']] : null;
            $v['category'] = !empty($v['categoryName']) ? ['id' => $v['categoryId'], 'name' => $v['categoryName']] : null;
            $v['uploader'] = !empty($v['uploaderName']) ? ['id' => $v['uploaderId'], 'name' => $v['uploaderName']] : null;
        }
        return $videos;
    }

    public static function getVideoById(int $id): ?array {
        $v = self::getOne("
            SELECT v.*, u.name AS uploaderName, d.name AS departmentName, c.name AS categoryName
            FROM videos v
            LEFT JOIN users u ON v.uploaderId = u.id
            LEFT JOIN departments d ON v.departmentId = d.id
            LEFT JOIN categories c ON v.categoryId = c.id
            WHERE v.id = ?
        ", [$id]);
        if ($v) {
            $v['department'] = !empty($v['departmentName']) ? ['id' => $v['departmentId'], 'name' => $v['departmentName']] : null;
            $v['category'] = !empty($v['categoryName']) ? ['id' => $v['categoryId'], 'name' => $v['categoryName']] : null;
            $v['uploader'] = !empty($v['uploaderName']) ? ['id' => $v['uploaderId'], 'name' => $v['uploaderName']] : null;
        }
        return $v;
    }

    public static function createVideo(array $data): int {
        return self::execute("
            INSERT INTO videos (title, description, departmentId, categoryId, uploaderId, videoUrl, status, tags, createdAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ", [
            $data['title'] ?? '',
            $data['description'] ?? '',
            !empty($data['departmentId']) ? (int)$data['departmentId'] : null,
            !empty($data['categoryId']) ? (int)$data['categoryId'] : null,
            (int)$data['uploaderId'],
            $data['videoUrl'] ?? '',
            $data['status'] ?? 'pending',
            $data['tags'] ?? '',
            self::toMySQLDate()
        ]);
    }

    public static function updateVideo(int $id, array $data): bool {
        $allowed = ['title', 'description', 'departmentId', 'categoryId', 'status', 'tags', 'videoUrl', 'rejectionRemarks', 'approvedBy', 'approvedAt', 'isRecommended', 'viewCount'];
        $fields = [];
        $params = [];
        foreach ($data as $key => $val) {
            if (in_array($key, $allowed, true)) {
                $fields[] = "`$key` = ?";
                $params[] = $val;
            }
        }
        if (empty($fields)) return false;
        $params[] = $id;
        self::execute("UPDATE videos SET " . implode(', ', $fields) . " WHERE id = ?", $params);
        return true;
    }

    // --- BOOKMARKS ---
    public static function getUserBookmarks(int $userId): array {
        $bookmarks = self::query("SELECT * FROM bookmarks WHERE userId = ? ORDER BY createdAt DESC", [$userId]);
        $results = [];

        foreach ($bookmarks as $bm) {
            $item = null;
            if ($bm['contentType'] === 'task') {
                $item = self::getTaskById((int)$bm['contentId']);
            } elseif ($bm['contentType'] === 'knowledge') {
                $item = self::getKnowledgePostById((int)$bm['contentId']);
            } elseif ($bm['contentType'] === 'video') {
                $item = self::getVideoById((int)$bm['contentId']);
            }

            if ($item) {
                $bm['content'] = $item;
                $results[] = $bm;
            }
        }

        return $results;
    }

    public static function createBookmark(int $userId, string $contentType, int $contentId): int {
        return self::execute(
            "INSERT IGNORE INTO bookmarks (userId, contentType, contentId, createdAt) VALUES (?, ?, ?, NOW())",
            [$userId, $contentType, $contentId]
        );
    }

    public static function deleteBookmark(int $userId, string $contentType, int $contentId): bool {
        self::execute(
            "DELETE FROM bookmarks WHERE userId = ? AND contentType = ? AND contentId = ?",
            [$userId, $contentType, $contentId]
        );
        return true;
    }

    // --- COMMENTS ---
    public static function getComments(array $filters = []): array {
        $sql = "SELECT c.*, u.name AS userName, u.role AS userRole FROM comments c LEFT JOIN users u ON c.userId = u.id WHERE 1=1";
        $params = [];
        if (!empty($filters['videoId'])) {
            $sql .= " AND c.videoId = ?";
            $params[] = (int)$filters['videoId'];
        }
        if (!empty($filters['taskId'])) {
            $sql .= " AND c.taskId = ?";
            $params[] = (int)$filters['taskId'];
        }
        $sql .= " ORDER BY c.createdAt ASC";
        $rows = self::query($sql, $params);
        foreach ($rows as &$r) {
            $r['user'] = !empty($r['userName']) ? ['id' => $r['userId'], 'name' => $r['userName']] : null;
        }
        return $rows;
    }

    public static function createComment(array $data): int {
        return self::execute("
            INSERT INTO comments (videoId, taskId, userId, parentId, body, createdAt)
            VALUES (?, ?, ?, ?, ?, NOW())
        ", [
            !empty($data['videoId']) ? (int)$data['videoId'] : null,
            !empty($data['taskId']) ? (int)$data['taskId'] : null,
            (int)$data['userId'],
            !empty($data['parentId']) ? (int)$data['parentId'] : null,
            $data['body']
        ]);
    }

    // --- NOTIFICATIONS ---
    public static function getNotifications(int $userId): array {
        return self::query("
            SELECT * FROM notifications
            WHERE userId = ?
            ORDER BY createdAt DESC
            LIMIT 50
        ", [$userId]);
    }

    public static function createNotification(array $data): int {
        return self::execute("
            INSERT INTO notifications (userId, type, message, taskId, videoId, readAt, createdAt)
            VALUES (?, ?, ?, ?, ?, NULL, NOW())
        ", [
            (int)$data['userId'],
            $data['type'],
            $data['message'],
            !empty($data['taskId']) ? (int)$data['taskId'] : null,
            !empty($data['videoId']) ? (int)$data['videoId'] : null
        ]);
    }

    // --- SITE SETTINGS ---
    public static function getSiteSettings(): array {
        $row = self::getOne("SELECT portalName, logoUrl, faviconUrl FROM site_settings LIMIT 1");
        return $row ?: [
            'portalName' => 'TaskIQ',
            'logoUrl' => '',
            'faviconUrl' => ''
        ];
    }

    public static function updateSiteSettings(array $data): array {
        self::execute(
            "UPDATE site_settings SET portalName = COALESCE(?, portalName), logoUrl = COALESCE(?, logoUrl), faviconUrl = COALESCE(?, faviconUrl)",
            [$data['portalName'] ?? null, $data['logoUrl'] ?? null, $data['faviconUrl'] ?? null]
        );
        return self::getSiteSettings();
    }

    // --- RECOMMENDED CONTENT ---
    public static function getRecommendedContent(): array {
        $knowledge = self::query("
            SELECT 'knowledge' AS type, k.id, k.title, k.description, k.tags, k.createdAt,
                   d.name AS departmentName, c.name AS categoryName, u.name AS uploaderName
            FROM knowledge_posts k
            LEFT JOIN departments d ON k.departmentId = d.id
            LEFT JOIN categories c ON k.categoryId = c.id
            LEFT JOIN users u ON k.uploaderId = u.id
            WHERE k.isRecommended = 1 AND k.status = 'published'
            ORDER BY k.createdAt DESC
            LIMIT 10
        ");

        $tasks = self::query("
            SELECT 'task' AS type, t.id, t.title, t.description, t.tags, t.createdAt,
                   d.name AS departmentName, c.name AS categoryName, u.name AS uploaderName
            FROM tasks t
            LEFT JOIN departments d ON t.departmentId = d.id
            LEFT JOIN categories c ON t.categoryId = c.id
            LEFT JOIN users u ON t.uploaderId = u.id
            WHERE t.status = 'approved'
            ORDER BY t.createdAt DESC
            LIMIT 10
        ");

        return array_merge($knowledge, $tasks);
    }

    // --- OTP ---
    public static function createOtp(string $email, string $otp, string $purpose, ?array $metadata = null, int $expiresInMinutes = 10): int {
        return self::execute("
            INSERT INTO otps (email, otp, purpose, metadata, expiresAt, createdAt)
            VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE), NOW())
        ", [
            $email,
            $otp,
            $purpose,
            $metadata ? json_encode($metadata) : null,
            $expiresInMinutes
        ]);
    }

    public static function getValidOtp(string $email, string $otp, string $purpose): ?array {
        return self::getOne("
            SELECT * FROM otps
            WHERE LOWER(email) = LOWER(?) AND otp = ? AND purpose = ? AND expiresAt > NOW()
            ORDER BY id DESC
            LIMIT 1
        ", [$email, $otp, $purpose]);
    }

    public static function deleteOtp(int $id): bool {
        self::execute("DELETE FROM otps WHERE id = ?", [$id]);
        return true;
    }

    // --- ACTIVITY LOGS ---
    public static function createActivityLog(int $userId, string $route, string $method = 'GET', string $userAgent = '', string $ipAddress = ''): int {
        return self::execute("
            INSERT INTO activity_logs (userId, route, method, userAgent, ipAddress, createdAt)
            VALUES (?, ?, ?, ?, ?, NOW())
        ", [$userId, $route, $method, $userAgent, $ipAddress]);
    }

    public static function getActivityLogsByUser(int $userId, int $limit = 200): array {
        return self::query("SELECT * FROM activity_logs WHERE userId = ? ORDER BY createdAt DESC LIMIT ?", [$userId, $limit]);
    }

    public static function getRecentActivityLogs(int $limit = 200): array {
        return self::query("SELECT al.*, u.name AS userName, u.email AS userEmail FROM activity_logs al LEFT JOIN users u ON al.userId = u.id ORDER BY al.createdAt DESC LIMIT ?", [$limit]);
    }

    // --- AI CHATS ---
    public static function createAiChat(int $userId, string $message, string $response, string $model = 'openrouter/free'): int {
        return self::execute("
            INSERT INTO ai_chats (userId, message, response, model, createdAt)
            VALUES (?, ?, ?, ?, NOW())
        ", [$userId, $message, $response, $model]);
    }

    public static function getAiChatsByUser(int $userId): array {
        return self::query("
            SELECT * FROM ai_chats WHERE userId = ? ORDER BY createdAt DESC LIMIT 50
        ", [$userId]);
    }
}
