<?php
// php-server/utils/email.php

class Mailer {
    public static function sendOtpEmail(string $toEmail, string $otp, string $purpose): array {
        $subject = ($purpose === "signup") ? "Verify your email to create your account" : "Your login OTP";
        $message = "Your OTP is {$otp}. It will expire in 10 minutes.";
        
        $smtpHost = getenv('SMTP_HOST') ?: ($_ENV['SMTP_HOST'] ?? '');
        $smtpUser = getenv('SMTP_USER') ?: ($_ENV['SMTP_USER'] ?? '');
        
        if (empty($smtpHost) || empty($smtpUser)) {
            error_log("[EMAIL FALLBACK] To: {$toEmail} | Subject: {$subject} | OTP: {$otp}");
            return ['fallback' => true];
        }

        $headers = "From: " . (getenv('SMTP_FROM') ?: ($_ENV['SMTP_FROM'] ?? 'no-reply@abmindia.com')) . "\r\n";
        $headers .= "Reply-To: " . (getenv('SMTP_FROM') ?: ($_ENV['SMTP_FROM'] ?? 'no-reply@abmindia.com')) . "\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

        $htmlMessage = "<p>Your OTP is <strong>{$otp}</strong>.</p><p>It will expire in 10 minutes.</p>";
        @mail($toEmail, $subject, $htmlMessage, $headers);

        return ['fallback' => false];
    }
}
